#!/bin/bash
configpath="/root/scripts.conf"
logpath="/root/observer.log"

while read -r scripts; do
	if ! pgrep -f "$scripts" > /dev/null;
	then
		nohup "$scripts" &
		echo "$(date '+%F %H:%M:%S') скрипт $scripts перезапущен" >> $logpath
	fi
done < "$configpath"
