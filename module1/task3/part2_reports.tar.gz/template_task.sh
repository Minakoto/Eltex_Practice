#!/bin/bash
DATE=$(date +%F)
TIME=$(date +%H:%M:%S)
MIN=30
MAX=1800
SLEEP_TIME=0
FILENAME=$(echo $0 |sed -e "s/\/root.\///g" | sed -e "s/\/root\///g" | sed -e "s/\.[^.]*$//")
echo $FILENAME
echo "[$$] ${DATE} ${TIME} Скрипт запущен" >> report_${FILENAME}.log
while [ "$SLEEP_TIME" -le $MIN ]
do
	SLEEP_TIME=$RANDOM
	((SLEEP_TIME %= $MAX))
done
sleep $SLEEP_TIME
DATE=$(date +%F)
TIME=$(date +%H:%M:%S)
((SLEEP_TIME /= 60))
echo "[$$] ${DATE} ${TIME} Скрипт завершился, рабтал ${SLEEP_TIME} минут" >> report_${FILENAME}.log

